"""
printing the 
Favourite band program
"""

# Setting Variables
Band = "Linkin Park"
Genre = "Rock"
Formed = "1996"
Vocalist = "Mike Shinoda"
Guitarist = "Brad Delson"
Bassist = "Dave Farrell"
DJ = "Joe Hahn"
Drummer = "Rob Bourdon"

# printing the variables
print (Band)
print (Genre)
print (Formed)
print (Vocalist)
print (Guitarist)
print (Bassist)
print (DJ)
print (Drummer)